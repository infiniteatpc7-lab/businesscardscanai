import React, { useState, useEffect } from 'react';
import {
    Search,
    Filter,
    Users,
    CheckCircle2,
    AlertTriangle,
    Eye,
    UserX,
    UserCheck,
    Building2,
    ChevronLeft,
    ChevronRight,
    Loader2
} from 'lucide-react';
import {
    fetchCustomers,
    fetchCustomerDetails,
    suspendCustomer,
    activateCustomer,
    fetchAdminWorkspaceDetails
} from '../../services/platformAdminApi';
import CustomerDetailDrawer from './CustomerDetailDrawer';
import WorkspaceDetailDrawer from './WorkspaceDetailDrawer';

export default function AdminCustomersView({ initialSelectedCustomerId, onClearSelectedCustomer }) {
    const [customers, setCustomers] = useState([]);
    const [pagination, setPagination] = useState({ current_page: 1, last_page: 1, total: 0 });
    const [searchQuery, setSearchQuery] = useState('');
    const [statusFilter, setStatusFilter] = useState('all'); // all | active | suspended
    const [isLoading, setIsLoading] = useState(false);

    // Detail drawer state
    const [selectedCustomer, setSelectedCustomer] = useState(null);
    const [isDetailLoading, setIsDetailLoading] = useState(false);

    // Workspace plan management modal/drawer state
    const [selectedWorkspaceForPlan, setSelectedWorkspaceForPlan] = useState(null);

    const handleManageWorkspacePlan = async (workspaceId) => {
        try {
            const res = await fetchAdminWorkspaceDetails(workspaceId);
            if (res.success && res.workspace) {
                setSelectedWorkspaceForPlan(res.workspace);
            } else {
                showToast('Failed to load workspace details', 'error');
            }
        } catch (err) {
            console.error('Failed to load workspace:', err);
            showToast('Unable to open workspace plan manager', 'error');
        }
    };

    // Suspend confirmation modal state
    const [suspendingCustomer, setSuspendingCustomer] = useState(null);
    const [suspendReason, setSuspendReason] = useState('');
    const [isActionPending, setIsActionPending] = useState(false);
    const [actionToast, setActionToast] = useState(null);

    const showToast = (message, type = 'info') => {
        setActionToast({ message, type });
        setTimeout(() => setActionToast(null), 4000);
    };

    const loadCustomers = async (page = 1) => {
        setIsLoading(true);
        try {
            const res = await fetchCustomers({
                page,
                search: searchQuery.trim(),
                status: statusFilter,
            });
            if (res.success && Array.isArray(res.customers)) {
                setCustomers(res.customers);
                setPagination(res.pagination || { current_page: 1, last_page: 1, total: 0 });
            }
        } catch (err) {
            console.error('Failed to load customers:', err);
            showToast('Failed to load customers list', 'error');
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        const timer = setTimeout(() => {
            loadCustomers(1);
        }, 250);
        return () => clearTimeout(timer);
    }, [searchQuery, statusFilter]);

    useEffect(() => {
        if (initialSelectedCustomerId) {
            handleOpenCustomerDetails(initialSelectedCustomerId);
            onClearSelectedCustomer?.();
        }
    }, [initialSelectedCustomerId]);

    const handleOpenCustomerDetails = async (id) => {
        setIsDetailLoading(true);
        try {
            const res = await fetchCustomerDetails(id);
            if (res.success && res.customer) {
                setSelectedCustomer(res.customer);
            }
        } catch (err) {
            console.error('Customer details error:', err);
            showToast('Unable to load customer details', 'error');
        } finally {
            setIsDetailLoading(false);
        }
    };

    const handleConfirmSuspend = async () => {
        if (!suspendingCustomer || !suspendReason.trim()) return;
        setIsActionPending(true);
        try {
            const res = await suspendCustomer(suspendingCustomer.id, suspendReason.trim());
            if (res.success) {
                showToast(`Customer account for "${suspendingCustomer.name}" suspended`, 'success');
                setSuspendingCustomer(null);
                setSuspendReason('');
                loadCustomers(pagination.current_page);
                if (selectedCustomer?.id === suspendingCustomer.id) {
                    setSelectedCustomer(null);
                }
            } else {
                showToast(res.message || 'Suspension failed', 'error');
            }
        } catch (err) {
            console.error('Suspend error:', err);
            showToast('Failed to suspend customer', 'error');
        } finally {
            setIsActionPending(false);
        }
    };

    const handleConfirmActivate = async (customer) => {
        if (!confirm(`Are you sure you want to reactivate ${customer.name}'s account?`)) {
            return;
        }
        setIsActionPending(true);
        try {
            const res = await activateCustomer(customer.id);
            if (res.success) {
                showToast(`Customer account for "${customer.name}" is now active`, 'success');
                loadCustomers(pagination.current_page);
                if (selectedCustomer?.id === customer.id) {
                    setSelectedCustomer(null);
                }
            } else {
                showToast(res.message || 'Activation failed', 'error');
            }
        } catch (err) {
            console.error('Activate error:', err);
            showToast('Failed to activate customer', 'error');
        } finally {
            setIsActionPending(false);
        }
    };

    return (
        <div className="space-y-5 select-none transition-colors">
            {/* Notification Toast */}
            {actionToast && (
                <div className={`p-3.5 rounded-xl border flex items-center justify-between text-xs font-medium ${
                    actionToast.type === 'error'
                        ? 'bg-rose-50 dark:bg-rose-950/40 border-rose-200 dark:border-rose-900/50 text-rose-800 dark:text-rose-400'
                        : actionToast.type === 'success'
                        ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-900/50 text-emerald-800 dark:text-emerald-400'
                        : 'bg-slate-100 dark:bg-zinc-800 border-slate-200 dark:border-zinc-700 text-slate-800 dark:text-zinc-200'
                }`}>
                    <span>{actionToast.message}</span>
                    <button onClick={() => setActionToast(null)} className="font-bold ml-4 text-slate-400 hover:text-slate-600 dark:hover:text-zinc-200">✕</button>
                </div>
            )}

            {/* Filter & Search Bar Card */}
            <div className="bg-white dark:bg-zinc-900 rounded-xl border border-slate-200/80 dark:border-zinc-800 p-4 shadow-xs space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                        <h2 className="text-base font-bold text-slate-900 dark:text-white tracking-tight">Customer Accounts</h2>
                        <p className="text-xs text-slate-500 dark:text-zinc-400">
                            Registered platform customers, tenant associations and account states
                        </p>
                    </div>

                    {/* Segmented Filter Buttons matching admincn */}
                    <div className="inline-flex rounded-lg bg-slate-100 dark:bg-zinc-800 p-0.5 border border-slate-200/70 dark:border-zinc-700">
                        {['all', 'active', 'suspended'].map((filter) => (
                            <button
                                key={filter}
                                onClick={() => setStatusFilter(filter)}
                                className={`px-3 py-1 rounded-md text-xs font-medium capitalize transition-all cursor-pointer ${
                                    statusFilter === filter
                                        ? 'bg-white dark:bg-zinc-900 text-slate-900 dark:text-white shadow-xs font-semibold'
                                        : 'text-slate-600 dark:text-zinc-400 hover:text-slate-900 dark:hover:text-white'
                                }`}
                            >
                                {filter}
                            </button>
                        ))}
                    </div>
                </div>

                {/* Search Input */}
                <div className="relative">
                    <Search className="w-4 h-4 text-slate-400 dark:text-zinc-500 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                    <input
                        type="text"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder="Search customers by name, email or workspace..."
                        className="w-full pl-9 pr-3.5 py-2 text-xs bg-slate-50/70 dark:bg-zinc-950 border border-slate-200 dark:border-zinc-800 rounded-lg text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-zinc-600 focus:outline-none focus:ring-1 focus:ring-orange-500 focus:border-orange-500 transition-colors"
                    />
                </div>
            </div>

            {/* Customers Table Card matching admincn Datatable */}
            <div className="bg-white dark:bg-zinc-900 rounded-xl border border-slate-200/80 dark:border-zinc-800 shadow-xs overflow-hidden">
                <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                        <thead>
                            <tr className="border-b border-slate-200/80 dark:border-zinc-800 bg-slate-50/70 dark:bg-zinc-900/90 text-[11px] font-semibold text-slate-500 dark:text-zinc-400 uppercase tracking-wider">
                                <th className="py-3 px-4">Customer</th>
                                <th className="py-3 px-4">Workspaces</th>
                                <th className="py-3 px-4 text-center">Cards</th>
                                <th className="py-3 px-4">Status</th>
                                <th className="py-3 px-4">Joined</th>
                                <th className="py-3 px-4 text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 dark:divide-zinc-800/80 text-xs text-slate-700 dark:text-zinc-300">
                            {isLoading ? (
                                <tr>
                                    <td colSpan="6" className="py-12 text-center text-slate-400 dark:text-zinc-500">
                                        <Loader2 className="w-5 h-5 animate-spin mx-auto text-orange-500 mb-2" />
                                        Loading customer records...
                                    </td>
                                </tr>
                            ) : customers.length === 0 ? (
                                <tr>
                                    <td colSpan="6" className="py-12 text-center text-slate-400 dark:text-zinc-500">
                                        <Users className="w-8 h-8 text-slate-300 dark:text-zinc-700 mx-auto mb-2" />
                                        No customer accounts match your search.
                                    </td>
                                </tr>
                            ) : (
                                customers.map((c) => {
                                    const isSuspended = c.status === 'suspended';
                                    return (
                                        <tr key={c.id} className="hover:bg-slate-50/70 dark:hover:bg-zinc-800/50 transition-colors">
                                            <td className="py-3 px-4">
                                                <div className="flex items-center gap-3">
                                                    <div className="size-8 rounded-full bg-slate-100 dark:bg-zinc-800 text-slate-700 dark:text-zinc-200 font-bold text-xs flex items-center justify-center border border-slate-200 dark:border-zinc-700 shrink-0">
                                                        {c.name?.charAt(0)?.toUpperCase() || 'U'}
                                                    </div>
                                                    <div className="min-w-0">
                                                        <p className="font-semibold text-slate-900 dark:text-white truncate">{c.name}</p>
                                                        <p className="text-[11px] text-slate-500 dark:text-zinc-400 truncate">{c.email}</p>
                                                    </div>
                                                </div>
                                            </td>
                                            <td className="py-3 px-4">
                                                <div className="flex flex-col gap-1 max-w-sm">
                                                    {c.workspaces && c.workspaces.length > 0 ? (
                                                        c.workspaces.map((w) => {
                                                            const isWsSuspended = w.workspace_status === 'suspended';
                                                            const subStatus = w.subscription_status || 'active';
                                                            const isSubActive = subStatus === 'active';
                                                            const planPrice = Number(w.plan?.price ?? 0);
                                                            const isPaid = !w.plan?.is_free && planPrice > 0;

                                                            return (
                                                                <div key={w.id} className="flex items-center gap-1.5 flex-wrap">
                                                                    <span className="inline-flex items-center gap-1 text-[11px] font-medium text-slate-800 dark:text-zinc-200">
                                                                        <Building2 className="w-2.5 h-2.5 text-slate-400" />
                                                                        <span className="truncate max-w-[110px]">{w.name}</span>
                                                                    </span>

                                                                    {/* Plan badge */}
                                                                    <span className={`inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-semibold border ${
                                                                        isPaid
                                                                            ? 'bg-orange-50 dark:bg-orange-950/40 text-orange-700 dark:text-orange-400 border-orange-200 dark:border-orange-900/50'
                                                                            : 'bg-slate-100 dark:bg-zinc-800 text-slate-600 dark:text-zinc-400 border-slate-200/70 dark:border-zinc-700'
                                                                    }`}>
                                                                        {w.plan?.name || 'Free Plan'}
                                                                        {isPaid && ` (₹${planPrice.toLocaleString('en-IN')})`}
                                                                    </span>

                                                                    {/* Subscription or workspace status indicator */}
                                                                    {isWsSuspended ? (
                                                                        <span className="inline-flex items-center px-1 py-0.2 rounded text-[9px] font-bold uppercase tracking-wider bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-400 border border-rose-200 dark:border-rose-900/50">
                                                                            Suspended
                                                                        </span>
                                                                    ) : !isSubActive ? (
                                                                        <span className="inline-flex items-center px-1 py-0.2 rounded text-[9px] font-bold uppercase tracking-wider bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-400 border border-amber-200 dark:border-amber-900/50">
                                                                            {subStatus}
                                                                        </span>
                                                                    ) : null}
                                                                </div>
                                                            );
                                                        })
                                                    ) : (
                                                        <span className="text-slate-400 dark:text-zinc-500 italic text-[11px]">No workspaces</span>
                                                    )}
                                                </div>
                                            </td>
                                            <td className="py-3 px-4 text-center font-bold text-slate-900 dark:text-white">
                                                {c.cards_count ?? 0}
                                            </td>
                                            <td className="py-3 px-4">
                                                <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-md text-[11px] font-semibold border ${
                                                    isSuspended
                                                        ? 'bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-400 border-rose-200 dark:border-rose-900/50'
                                                        : 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400 border-emerald-200 dark:border-emerald-900/50'
                                                }`}>
                                                    <span className={`size-1.5 rounded-full ${isSuspended ? 'bg-rose-500' : 'bg-emerald-500'}`} />
                                                    {isSuspended ? 'Suspended' : 'Active'}
                                                </span>
                                            </td>
                                            <td className="py-3 px-4 text-slate-500 dark:text-zinc-400 text-[11px] font-mono whitespace-nowrap">
                                                {c.created_at ? new Date(c.created_at).toLocaleDateString() : '—'}
                                            </td>
                                            <td className="py-3 px-4 text-right">
                                                <div className="flex items-center justify-end gap-1">
                                                    <button
                                                        onClick={() => handleOpenCustomerDetails(c.id)}
                                                        title="View customer details"
                                                        className="p-1.5 text-slate-500 dark:text-zinc-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-zinc-800 rounded-lg transition-colors cursor-pointer"
                                                    >
                                                        <Eye className="w-4 h-4" />
                                                    </button>

                                                    {isSuspended ? (
                                                        <button
                                                            onClick={() => handleConfirmActivate(c)}
                                                            title="Reactivate customer"
                                                            className="p-1.5 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 rounded-lg transition-colors cursor-pointer"
                                                        >
                                                            <UserCheck className="w-4 h-4" />
                                                        </button>
                                                    ) : (
                                                        <button
                                                            onClick={() => {
                                                                setSuspendingCustomer(c);
                                                                setSuspendReason('');
                                                            }}
                                                            title="Suspend customer"
                                                            className="p-1.5 text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition-colors cursor-pointer"
                                                        >
                                                            <UserX className="w-4 h-4" />
                                                        </button>
                                                    )}
                                                </div>
                                            </td>
                                        </tr>
                                    );
                                })
                            )}
                        </tbody>
                    </table>
                </div>

                {/* Pagination */}
                <div className="px-4 py-3 border-t border-slate-200/80 dark:border-zinc-800 bg-slate-50/50 dark:bg-zinc-900/60 flex items-center justify-between text-xs text-slate-500 dark:text-zinc-400">
                    <div>
                        Showing <span className="font-semibold text-slate-800 dark:text-zinc-200">
                            {customers.length > 0 ? (pagination.current_page - 1) * 15 + 1 : 0}
                        </span> to <span className="font-semibold text-slate-800 dark:text-zinc-200">
                            {Math.min(pagination.current_page * 15, pagination.total)}
                        </span> of <span className="font-semibold text-slate-800 dark:text-zinc-200">{pagination.total}</span> customers
                    </div>
                    <div className="flex items-center gap-1.5">
                        <button
                            disabled={pagination.current_page <= 1 || isLoading}
                            onClick={() => loadCustomers(pagination.current_page - 1)}
                            className="p-1.5 rounded-lg border border-slate-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 hover:bg-slate-50 dark:hover:bg-zinc-700 disabled:opacity-40 disabled:pointer-events-none transition-colors cursor-pointer"
                        >
                            <ChevronLeft className="w-4 h-4" />
                        </button>
                        <span className="text-slate-800 dark:text-zinc-200 font-medium px-2">
                            {pagination.current_page} / {pagination.last_page || 1}
                        </span>
                        <button
                            disabled={pagination.current_page >= pagination.last_page || isLoading}
                            onClick={() => loadCustomers(pagination.current_page + 1)}
                            className="p-1.5 rounded-lg border border-slate-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 hover:bg-slate-50 dark:hover:bg-zinc-700 disabled:opacity-40 disabled:pointer-events-none transition-colors cursor-pointer"
                        >
                            <ChevronRight className="w-4 h-4" />
                        </button>
                    </div>
                </div>
            </div>

            {/* Suspend Confirmation Modal */}
            {suspendingCustomer && (
                <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
                    <div className="bg-white dark:bg-zinc-900 rounded-xl max-w-md w-full p-6 shadow-xl border border-slate-200 dark:border-zinc-800 space-y-4">
                        <div className="flex items-center gap-3">
                            <div className="size-10 rounded-lg bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/50 text-rose-600 dark:text-rose-400 flex items-center justify-center shrink-0">
                                <AlertTriangle className="w-5 h-5" />
                            </div>
                            <div>
                                <h3 className="text-sm font-bold text-slate-900 dark:text-white">Suspend Customer Account</h3>
                                <p className="text-xs text-slate-500 dark:text-zinc-400">Security enforcement & policy hold</p>
                            </div>
                        </div>

                        <p className="text-xs text-slate-600 dark:text-zinc-300 leading-relaxed">
                            You are about to suspend <span className="font-semibold text-slate-900 dark:text-white">{suspendingCustomer.name}</span> ({suspendingCustomer.email}).
                            This restricts scanning, bulk uploads, and workspace card modifications while strictly preserving all customer data.
                        </p>

                        <div>
                            <label className="block text-xs font-semibold text-slate-700 dark:text-zinc-300 mb-1.5">
                                Reason for suspension <span className="text-rose-500">*</span>
                            </label>
                            <textarea
                                value={suspendReason}
                                onChange={(e) => setSuspendReason(e.target.value)}
                                rows={3}
                                placeholder="E.g., Terms violation, requested security freeze, chargeback review..."
                                className="w-full p-2.5 text-xs border border-slate-200 dark:border-zinc-700 rounded-lg bg-slate-50 dark:bg-zinc-950 focus:outline-none focus:ring-1 focus:ring-orange-500 focus:border-orange-500 text-slate-900 dark:text-white"
                            />
                        </div>

                        <div className="flex items-center justify-end gap-2.5 pt-2">
                            <button
                                type="button"
                                onClick={() => setSuspendingCustomer(null)}
                                disabled={isActionPending}
                                className="px-3.5 py-2 text-xs font-medium text-slate-600 dark:text-zinc-400 bg-white dark:bg-zinc-800 border border-slate-200 dark:border-zinc-700 rounded-lg hover:bg-slate-50 dark:hover:bg-zinc-700 transition-colors cursor-pointer"
                            >
                                Cancel
                            </button>
                            <button
                                type="button"
                                onClick={handleConfirmSuspend}
                                disabled={!suspendReason.trim() || isActionPending}
                                className="inline-flex items-center px-4 py-2 text-xs font-semibold text-white bg-rose-600 rounded-lg hover:bg-rose-700 transition-colors shadow-xs disabled:opacity-50 cursor-pointer"
                            >
                                {isActionPending && <Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" />}
                                Suspend Account
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* Customer Detail Drawer */}
            <CustomerDetailDrawer
                customer={selectedCustomer}
                isOpen={Boolean(selectedCustomer)}
                onClose={() => setSelectedCustomer(null)}
                onSuspendClick={(c) => {
                    setSuspendingCustomer(c);
                    setSuspendReason('');
                }}
                onActivateClick={(c) => handleConfirmActivate(c)}
                onManageWorkspacePlan={handleManageWorkspacePlan}
            />

            {/* Reusable Workspace Detail / Plan Change Drawer */}
            <WorkspaceDetailDrawer
                workspace={selectedWorkspaceForPlan}
                isOpen={Boolean(selectedWorkspaceForPlan)}
                onClose={() => setSelectedWorkspaceForPlan(null)}
                onPlanChanged={() => {
                    showToast('Workspace plan updated successfully', 'success');
                    loadCustomers(pagination.current_page);
                    if (selectedCustomer) {
                        handleOpenCustomerDetails(selectedCustomer.id);
                    }
                }}
            />
        </div>
    );
}
